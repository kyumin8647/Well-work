# 일잘노트

회사 고민을 털어놓으면 해결하고, 결정과 결과를 업무 자산으로 쌓는 주니어 실무 앱이에요.
MD·마케터·퍼포먼스·그로스·서비스기획·데이터 분석 직무 팩과 "가상 회사 출근 · MD 5일" 실무 체험이 들어 있어요.

## GitHub Pages로 올리기 (5분)

1. GitHub에서 **New repository**를 만들어요. 예: `ijalnote`, Public.
2. 저장소 화면에서 **Add file → Upload files**를 누르고, 이 폴더의 파일(`index.html`, `favicon.svg`, `.nojekyll`, `README.md`)을 끌어다 놓고 **Commit changes**를 눌러요.
   - `.nojekyll`은 숨김 파일이라 안 보일 수 있어요. 없어도 동작하지만, 있으면 GitHub가 파일을 그대로 올려요.
3. **Settings → Pages**에서 Source는 **Deploy from a branch**, Branch는 **main / (root)**를 고르고 저장해요.
4. 1~2분 뒤 `https://내아이디.github.io/ijalnote/` 주소로 열려요.

## 이 버전에서 되는 것과 안 되는 것

- **돼요:** 모든 화면, 직무 팩, 선배 케이스, 계산기, MD 5일 출근 체험, 성과 정리
- **기록 저장:** 각자 브라우저(이 기기)에만 저장돼요. 다른 사람에게는 보이지 않아요. 공용 기기에서는 성과 탭의 "기록 지우기"를 눌러 주세요.
- **AI 검토 대신 기본 검토 의견:** GitHub Pages에는 서버가 없어서 AI 대신 직무별 기본 검토 의견이 나와요.
- **Google 로그인·기기 간 동기화:** GitHub Pages 버전에는 없어요. 필요하면 Firebase 배포 버전(`ijalnote-web` 프로젝트)을 쓰세요.

## 파일

| 파일 | 내용 |
| --- | --- |
| `index.html` | 앱 전체(화면·글꼴·코드)가 들어 있는 한 파일 |
| `favicon.svg` | 브라우저 탭 아이콘 |
| `.nojekyll` | GitHub Pages가 파일을 가공하지 않게 하는 빈 파일 |
